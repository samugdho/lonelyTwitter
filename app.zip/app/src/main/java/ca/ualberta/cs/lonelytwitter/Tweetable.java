package ca.ualberta.cs.lonelytwitter;

import java.util.Date;

/**
 * Created by Sadman on 2017-09-14.
 */

public interface Tweetable {
    public String getMessage();
    public Date getDate();
}
