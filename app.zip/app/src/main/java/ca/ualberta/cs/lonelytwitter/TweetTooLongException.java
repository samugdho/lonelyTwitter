package ca.ualberta.cs.lonelytwitter;

/**
 * Created by Sadman on 2017-09-14.
 */

public class TweetTooLongException extends Exception {
}
